package org.example.sudoku;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.app.Activity;
import android.view.View;
import android.widget.Button;

public class Map extends Activity implements View.OnClickListener{
    private static final String TAG="Go Green";
    Button upstairs_button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.d(TAG, "Map opened");
        setContentView(R.layout.map);
        upstairs_button = (Button) findViewById(R.id.upstairs_button);
        View energy = findViewById(R.id.upstairs_button);
        energy.setOnClickListener(this);
    }



    public void onClick(View v){
        switch (v.getId()) {
            case R.id.upstairs_button:
               Intent h=new Intent(this,Map2.class);
                startActivity(h);
                break;
            //case R.id.back_button:
              //  finish();
                //break;
        }
    }

}
