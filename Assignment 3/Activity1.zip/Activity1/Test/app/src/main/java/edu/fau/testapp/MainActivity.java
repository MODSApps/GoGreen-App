package edu.fau.testapp;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.*;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.util.ArrayList;


public class MainActivity extends Activity {
    TextView tv_qq, ques,guesses_left;
    EditText et_answer;
    Button btn_submit;
    String[]words={"recycle","environment","hello"};
    String word;
    ArrayList<String> guessed;
    int left;
    String[]lines;
    private static final String TAG="hangman";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tv_qq = (TextView) findViewById(R.id.tv_qq);
        ques = (TextView) findViewById(R.id.ques);
        guesses_left = (TextView) findViewById(R.id.guesses_left);
        et_answer = (EditText) findViewById(R.id.editText);
        btn_submit = (Button) findViewById(R.id.btn_submit);
        tv_qq.setText("How are you feeling?");
        Log.d(TAG, "yr");
        guessed=new ArrayList<String>();
        setup();
        while(left>0)
            turn();
//        btn_submit.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                checkAnswer(v);
//            }
//        });
    }

    public void setup(){
        guessed.clear();
        word=words[(int)(Math.random()*words.length)];
        lines=new String[word.length()];
        String s="";
        for(int i=0;i<word.length();i++)
            lines[i] = "____   ";
        tv_qq.setText(arrayToString(lines));
        left=6;
        guesses_left.setText((left+""));
    }
    private String arrayToString(String[]arr){
        String s="";
        for(String h:arr)
            s+=h+"";
        return s;
    }
    public void turn(){
        int c=0;
        ques.setText("Guess a letter!");
        String let=et_answer.getText().toString();
        String s=(String)tv_qq.getText();
        for(int i=0;i<word.length()-1;i++) {
            if (word.substring(i, i + 1).equals(let))
                lines[i] = let;
            else
                c++;
        }
        if(c==word.length()) {
            left -= 1;
            guessed.add(let);
        }
        tv_qq.setText(arrayToString(lines));
        guesses_left.setText((left+""));
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    public void checkAnswer(View view){
        if ( et_answer.getText().toString().equalsIgnoreCase("Good")){
            ques.setText("!!!This is correct!!!");
        }
        else {
            ques.setText("This is incorrect :(");
        }
    }
}
