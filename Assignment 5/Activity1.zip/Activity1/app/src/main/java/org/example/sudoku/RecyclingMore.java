package org.example.sudoku;

/**
 * Created by Alissa on 7/19/2015.
 */
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

public class RecyclingMore extends Activity implements View.OnClickListener{
    private static final String TAG="Go Green";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.d(TAG, "More Recycling");
        setContentView(R.layout.recycling_more);
        View energy = findViewById(R.id.cardboard_button);
        energy.setOnClickListener(this);
        View energ = findViewById(R.id.phone_button);
        energ.setOnClickListener(this);
        View continueButton = findViewById(R.id.can_button);
        continueButton.setOnClickListener(this);
        View game_button = findViewById(R.id.paper_button);
        game_button.setOnClickListener(this);
        View aboutButton = findViewById(R.id.socks_button);
        aboutButton.setOnClickListener(this);
    }

    public void onClick(View v){
        switch (v.getId()) {
            case R.id.cardboard_button:
                Intent i=new Intent(this,RecCardboard.class);
                startActivity(i);
                break;
            case R.id.phone_button:
                Intent p = new Intent(this, RecPhone.class);
                startActivity(p);
                break;
            case R.id.can_button:
                Log.d(TAG,"can");
                Intent h=new Intent(this,RecCan.class);
                startActivity(h);
                break;
            case R.id.paper_button:
                Intent a=new Intent(this,RecPaper.class);
                startActivity(a);
                break;
            case R.id.socks_button:
                Intent b=new Intent(this,RecSocks.class);
                startActivity(b);
                break;
        }
    }
}

