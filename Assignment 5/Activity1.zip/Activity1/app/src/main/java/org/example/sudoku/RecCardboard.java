package org.example.sudoku;

/**
 * Created by Alissa on 7/19/2015.
 */
import android.app.Activity;
import android.os.Bundle;



public class RecCardboard extends Activity {
    private static final String TAG="Go Green";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.rec_cardboard);
    }
}
