/** Automatically generated file. DO NOT MODIFY */
package org.example.sudoku;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}